from pathlib import Path
import datetime,json,os,subprocess
root=Path.cwd();base=root/'.context'
assert not subprocess.check_output(['git','status','--porcelain'],text=True)
command=['python3','-B','hack/bench-dedicated.py','qualify','--host-record','.context/performance-host-reviewed.json','--reference','.context/performance-reference','--calibration','.context/performance-method/bench/calibration/cloud-shared-20261115/calibration','--approval','.context/performance-method/bench/calibration/cloud-shared-20261115/approval.json','--host-transition-approval','.context/performance-host-transition-approved.json','--output','.context/performance-final-corrected-20261116']
record={'command':command,'candidate_source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(base/'performance-corrected-started.json').write_text(json.dumps(record,indent=2)+'\n')
env=dict(os.environ,CGO_ENABLED='0',GOTOOLCHAIN='go1.27.4')
with (base/'performance-final-corrected-console.log').open('xb') as output:
 result=subprocess.run(command,env=env,stdout=output,stderr=subprocess.STDOUT)
record.update(exit_code=result.returncode,completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
(base/'performance-corrected-execution-result.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
raise SystemExit(result.returncode)
