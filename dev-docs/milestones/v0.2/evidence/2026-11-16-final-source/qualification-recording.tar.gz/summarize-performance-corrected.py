"""Summarize the completed recording without launching benchmark processes."""
import csv
import importlib.util
import json
from pathlib import Path
import re
import statistics

BASE = Path(__file__).resolve().parent
METHOD = BASE.parent
PAIR = BASE / 'performance-final-corrected-20261116/paired'
spec = importlib.util.spec_from_file_location('dedicated', METHOD / 'hack/bench-dedicated.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
verified = json.loads((BASE / 'performance-corrected-verification.json').read_text())
assert verified['native_commands'] == 60 and verified['performance_pass'] is False
fixed = []
vectors = []
for role, reports in (('reference', m.reference.REPORTS), ('candidate', m.runner.REPORTS)):
    for report in reports:
        measured = m.vectors((PAIR / role / (report + '.txt')).read_text())
        for (name, unit), values in sorted(measured.items()):
            median = statistics.median(values)
            vectors.append({'role': role, 'report': report, 'name': name, 'unit': unit,
                            **{f'sample_{i}': value for i, value in enumerate(values, 1)},
                            'median': median})
        if report != 'blocking-zone':
            continue
        for line in (METHOD / 'bench/limits.txt').read_text().splitlines():
            fields = line.split()
            if not fields or fields[0] != 'limit':
                continue
            _, pattern, unit, bound = fields
            for (name, metric_unit), values in sorted(measured.items()):
                if unit == metric_unit and re.search(pattern, name):
                    median = statistics.median(values)
                    fixed.append({'role': role, 'name': name, 'unit': unit, 'values': values,
                                  'median': median, 'limit': float(bound), 'pass': median <= float(bound)})
assert fixed
assert any(not row['pass'] for row in fixed)
(BASE / 'performance-corrected-fixed-product-metrics.json').write_text(json.dumps(fixed, indent=2) + '\n')
with (BASE / 'performance-corrected-metric-vectors.csv').open('w', newline='') as output:
    writer = csv.DictWriter(output, fieldnames=list(vectors[0]), lineterminator='\n')
    writer.writeheader()
    writer.writerows(vectors)
print(f"Verified {len(vectors)} metric vectors and {len(fixed)} fixed-product checks")
